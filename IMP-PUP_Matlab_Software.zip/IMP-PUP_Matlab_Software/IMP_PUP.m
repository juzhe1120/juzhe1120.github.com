clc
clear

Data_preprocessing  % Data preprocessing and CKSAAP feature extraction

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Predicting %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load('MODEL') 
% 'MODEL.mat' includes the two .mat files: 'Feature.mat' and 'model.mat'.
% 'Feature.mat' includes 200 optimal CKSAAP features; 
% 'model.mat' includes a SVM model which have been trained by the proposed semi-supervised self-training SVM algorithm
testdata=test_data(:,Feature);  % F-score feature selection
testlabel=-ones(size(test_data,1),1); % testlabel can be randomly assigned
[predict_label, accuracy,dec_values] = svmpredict(testlabel, testdata, model); % predicting 
clc
Pre_score=dec_values;
disp(['The prediction results have been saved to result file "Pre_result.xls".']);

%%%%%%%%%%%%%%%%%%%%%%%%%%%% Prediction over %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%% The predicted results output %%%%%%%%%%%%%%%%%%%%%%%%%%%

Label_High=testlabel;
Label_High(dec_values>=0.67)=1;  % Thresholds 'High' of IMP-PUP was set to 0.67

Label_Med=testlabel;
Label_Med(dec_values>=0.1)=1;     % Thresholds 'Med' of IMP-PUP was set to 0.1

Label_Low=testlabel;            
Label_Low(dec_values>=-0.2)=1; % Thresholds 'Low' of IMP-PUP was set to -0.2


 for i=1:size(test_data,1)
      ID(i,1)=result1{i,1};
      position(i,1)=result1{i,2};
 end
  
A1=[{'Protein ID'} {'Lysine_position'} {'Pupylation?'}  '(Yes:1, No:-1)' {''} {'SVM_score'} ];
B1=[{''} {''} {'Threshold: High'} {'Threshold: Medium'} {'Threshold: Low'} '(Higher SVM scores indicate more reliable pupylation sites)'];
aa=[];
for i=1:size(test_data,1)
   a= {ID{i,1} position(i,1) Label_High(i,1) Label_Med(i,1) Label_Low(i,1) Pre_score(i,1)};
   aa=[aa ;a];
end
aaa=[A1;B1;aa];
xlswrite('Pre_result.xls', aaa);
winopen('Pre_result.xls');  %Open the result file "Pre_result.xls".
clear all